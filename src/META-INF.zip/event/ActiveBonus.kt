package event

data class ActiveBonus(
  val type: String,
  val ticks: Int
)