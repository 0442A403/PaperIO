package event

data class Tick(
  val type: String,
  val params: Params
)